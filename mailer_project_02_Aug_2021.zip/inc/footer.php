 <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>All Rights Reserved &copy; Bulk Mail Sending 2021</span>
          </div>
        </div>
      </footer>